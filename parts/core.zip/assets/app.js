(()=>{const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const LS={get:(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch(e){return d}},set:(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('on'),1800)};
let IDX=null;const idx=()=>IDX?Promise.resolve(IDX):fetch('/search-index.json').then(r=>r.json()).then(j=>IDX=j);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// theme
$('#theme')?.addEventListener('click',()=>{const h=document.documentElement,n=h.dataset.theme==='dark'?'light':'dark';h.dataset.theme=n;LS.set('dq-theme',n);localStorage.setItem('dq-theme',n)});
try{const t=localStorage.getItem('dq-theme');if(t)document.documentElement.dataset.theme=t.replace(/"/g,'')}catch(e){}
// streak / level
const today=new Date().toISOString().slice(0,10);let st=LS.get('dq-streak',{last:'',days:0,visits:0});
if(st.last!==today){const y=new Date(Date.now()-864e5).toISOString().slice(0,10);st.days=st.last===y?st.days+1:1;st.last=today}st.visits++;LS.set('dq-streak',st);
const rx=LS.get('dq-rx',{}),sv=LS.get('dq-saved',[]);const pts=st.visits+Object.keys(rx).length*2+sv.length*3;
const lv=[[0,'Lurker'],[10,'Chuckler'],[30,'Meme Scout'],[70,'Caption Connoisseur'],[150,'Group Chat Legend'],[300,'Certified Unhinged']];let L=1,N='Lurker';lv.forEach((x,i)=>{if(pts>=x[0]){L=i+1;N=x[1]}});
if($('#lvl')){$('#lvl').textContent='🔥 '+st.days;$('#lvl').title=`${st.days}-day streak · Level ${L} ${N}`}
if($('#streak')){$('#streak').textContent=`🔥 ${st.days} day${st.days>1?'s':''}`;$('#lvltext').textContent=`Level ${L} · ${N} · ${pts} pts`}
// reactions & saves
const seed=s=>{let h=0;for(const c of s)h=(h*31+c.codePointAt(0))>>>0;return h};
function wire(root=document){$$('[data-id]',root).forEach(el=>{const id=el.dataset.id;
 $$('.rx',el).forEach(b=>{if(b._w)return;b._w=1;const k=id+b.dataset.rx,base=seed(k)%40+3;const upd=()=>{b.querySelector('span').textContent=base+(rx[k]?1:0);b.classList.toggle('on',!!rx[k]);b.setAttribute('aria-pressed',!!rx[k])};upd();
  b.addEventListener('click',()=>{rx[k]?delete rx[k]:rx[k]=Date.now();LS.set('dq-rx',rx);upd();if(rx[k])toast(b.dataset.rx+' noted')})});
 $$('.sv',el).forEach(b=>{if(b._w)return;b._w=1;const upd=()=>{const on=sv.includes(id);b.textContent=on?'★ Saved':'☆ Save';b.classList.toggle('on',on);b.setAttribute('aria-pressed',on)};upd();
  b.addEventListener('click',()=>{const i=sv.indexOf(id);i<0?sv.push(id):sv.splice(i,1);LS.set('dq-saved',sv);upd();toast(i<0?'Saved':'Removed')})})});
 $$('[data-copy]',root).forEach(b=>{if(b._w)return;b._w=1;b.addEventListener('click',()=>{navigator.clipboard?.writeText(b.dataset.copy).then(()=>toast('Link copied'),()=>prompt('Copy this link',b.dataset.copy))})});
 $$('[data-share]',root).forEach(b=>{if(b._w)return;b._w=1;if(!navigator.share){b.hidden=true;return}b.addEventListener('click',()=>navigator.share({title:'dirtyquote',text:b.dataset.text,url:b.dataset.share}).catch(()=>{}))});
 $$('.surprise',root).forEach(b=>{if(b._w)return;b._w=1;b.addEventListener('click',surprise)})}
function surprise(){idx().then(j=>{location.href='/meme/'+j[Math.floor(Math.random()*j.length)].s+'.html'})}
const U=s=>'https://dirtyquote.com/meme/'+s+'.html',enc=encodeURIComponent;
function cardHTML(m){const u=U(m.s),t=enc(m.c+' via dirtyquote.com'),img=enc('https://dirtyquote.com/img/'+m.s+'.jpg');
return `<article class="card" data-id="${m.s}"><a href="/meme/${m.s}.html" class="cimg"><img src="/img/${m.s}-540.webp" alt="${esc(m.c)}" loading="lazy" width="540" height="540"></a><div class="cbody"><a class="pill" href="/category/${m.k}.html">${esc(m.n)}</a><p>${esc(m.c)}</p><div class="acts"><button class="rx" data-rx="😂">😂 <span>0</span></button><button class="rx" data-rx="🔥">🔥 <span>0</span></button><button class="sv">☆ Save</button>
<details class="share"><summary>Share</summary><div class="shares"><a class="sh" target="_blank" rel="noopener nofollow" href="https://www.facebook.com/sharer/sharer.php?u=${enc(u)}">Facebook</a><a class="sh" target="_blank" rel="noopener nofollow" href="https://twitter.com/intent/tweet?text=${t}&url=${enc(u)}">X</a><a class="sh" target="_blank" rel="noopener nofollow" href="https://pinterest.com/pin/create/button/?url=${enc(u)}&media=${img}&description=${t}">Pinterest</a><a class="sh" target="_blank" rel="noopener nofollow" href="https://www.reddit.com/submit?url=${enc(u)}&title=${t}">Reddit</a><a class="sh" target="_blank" rel="noopener nofollow" href="https://wa.me/?text=${t}%20${enc(u)}">WhatsApp</a><a class="sh" href="mailto:?subject=This%20meme%20is%20me&body=${t}%20${enc(u)}">Email</a><button class="sh" data-copy="${u}">Copy link</button><button class="sh" data-share="${u}" data-text="${esc(m.c)} via dirtyquote.com">Share…</button><a class="sh dl" href="/img/${m.s}.jpg" download>Download</a></div></details></div></div></article>`}
// search
const norm=s=>s.toLowerCase().replace(/[^a-z0-9 ]/g,' ');
function search(q,j){q=norm(q).trim();if(!q)return[];const terms=q.split(/\s+/);
 return j.map(m=>{const hay=norm(m.c+' '+m.n+' '+m.t+' '+m.k);let s=0;for(const t of terms){if(hay.includes(' '+t))s+=3;else if(hay.includes(t))s+=1;else return null}if(norm(m.n).includes(q))s+=5;return[s,m]}).filter(Boolean).sort((a,b)=>b[0]-a[0]).map(x=>x[1])}
const POP=['ghosted','monday','boss','rent','coffee','ex','cat','petty','group chat','snack','gym','sleep'];
if($('#sres')){idx().then(j=>{const q=new URLSearchParams(location.search).get('q')||'';const inp=$('#sq');inp.value=q;
 $('#popular').innerHTML=POP.map(p=>`<a href="?q=${enc(p)}">${p}</a>`).join('');
 const words=[...new Set(j.flatMap(m=>norm(m.c+' '+m.t+' '+m.n).split(/\s+/)).filter(w=>w.length>3))].sort();
 const run=()=>{const v=inp.value,r=search(v,j);$('#sres').innerHTML=r.slice(0,120).map(cardHTML).join('');$('#scount').textContent=v?`${r.length} meme${r.length==1?'':'s'} for “${v}”`+(r.length?'':' — try one of the popular searches above'):'';wire($('#sres'));
  const last=norm(v).split(' ').pop();$('#sugg').innerHTML=last.length>1?words.filter(w=>w.startsWith(last)).slice(0,8).map(w=>`<option value="${esc(v.slice(0,v.length-last.length)+w)}">`).join(''):'';
  history.replaceState(null,'',v?'?q='+enc(v):location.pathname)};
 inp.addEventListener('input',run);$('#sform').addEventListener('submit',e=>{e.preventDefault();run()});run();
 const saved=j.filter(m=>sv.includes(m.s));$('#savedgrid').innerHTML=saved.length?saved.map(cardHTML).join(''):'<p class="small">Nothing saved yet. Tap ☆ Save on any meme.</p>';wire($('#savedgrid'))})}
// daily drop + leaderboard
if($('#dailyc')){idx().then(j=>{const d=Math.floor(Date.now()/864e5);$('#dailyc').innerHTML=cardHTML(j[(d*7919)%j.length]);wire($('#dailyc'));
 const mine=Object.keys(rx);if(mine.length){const score={};mine.forEach(k=>{const s=k.replace(/(😂|🔥|💀)$/u,'');score[s]=(score[s]||0)+1});
  const top=Object.entries(score).sort((a,b)=>b[1]-a[1]).slice(0,3).map(([s])=>j.find(m=>m.s===s)).filter(Boolean);
  if(top.length)$('#lb').insertAdjacentHTML('afterbegin',top.map(m=>`<li><a href="/meme/${m.s}.html">${esc(m.c)}</a><span class="pill">your pick</span></li>`).join(''))}})}
// reels
if($('#reels')){idx().then(j=>{const cat=new URLSearchParams(location.search).get('cat');let list=cat?j.filter(m=>m.k===cat):j.slice();for(let i=list.length-1;i>0;i--){const r=Math.floor(Math.random()*(i+1));[list[i],list[r]]=[list[r],list[i]]}
 let n=0;const R=$('#reels');const more=()=>{const chunk=list.slice(n,n+10);n+=10;R.insertAdjacentHTML('beforeend',chunk.map(m=>`<section class="reel" data-id="${m.s}"><img src="/img/${m.s}.webp" alt="${esc(m.c)}" loading="lazy"><div class="acts big" style="justify-content:center"><button class="rx" data-rx="😂">😂 <span>0</span></button><button class="rx" data-rx="🔥">🔥 <span>0</span></button><button class="sv">☆ Save</button><a class="sh" href="/meme/${m.s}.html">Open & share</a></div></section>`).join(''));wire(R)};
 more();R.addEventListener('scroll',()=>{if(R.scrollTop+R.clientHeight*3>R.scrollHeight&&n<list.length)more()});
 document.addEventListener('keydown',e=>{if(e.key==='j'||e.key==='ArrowDown'){R.scrollBy({top:R.clientHeight,behavior:'smooth'});e.preventDefault()}if(e.key==='k'||e.key==='ArrowUp'){R.scrollBy({top:-R.clientHeight,behavior:'smooth'});e.preventDefault()}})})}
// command palette
const pal=$('#pal'),pq=$('#palq'),pr=$('#palr');let sel=0,CATS=null;
const cmds=[['🎲 Surprise me',()=>surprise()],['▶ Scroll mode','/scroll.html'],['◐ Toggle theme',()=>$('#theme').click()],['🔎 Search page','/search.html'],['★ Saved memes','/search.html#saved'],['✉ Submit an idea','/submit.html']];
function openPal(){pal.hidden=false;pq.value='';renderPal();pq.focus();if(!CATS)fetch('/cats.json').then(r=>r.json()).then(c=>{CATS=c;renderPal()});idx()}
function closePal(){pal.hidden=true}
function renderPal(){const q=pq.value.trim().toLowerCase();let items=cmds.filter(c=>!q||c[0].toLowerCase().includes(q)).map(c=>({l:c[0],a:c[1]}));
 (CATS||[]).filter(c=>!q||c.n.toLowerCase().includes(q)).slice(0,q?6:20).forEach(c=>items.push({l:'Mood · '+c.n,a:'/category/'+c.k+'.html'}));
 if(q&&IDX)search(q,IDX).slice(0,8).forEach(m=>items.push({l:'“'+m.c+'”',a:'/meme/'+m.s+'.html'}));
 if(q)items.push({l:'Search all for “'+q+'”',a:'/search.html?q='+enc(q)});sel=Math.min(sel,items.length-1);pal._items=items;
 pr.innerHTML=items.map((it,i)=>`<li class="${i===sel?'sel':''}"><a href="${typeof it.a==='string'?it.a:'#'}" data-i="${i}">${esc(it.l)}</a></li>`).join('')}
function go(i){const it=pal._items[i];if(!it)return;if(typeof it.a==='string')location.href=it.a;else{closePal();it.a()}}
if(pal){$('#cmdk').addEventListener('click',openPal);pq.addEventListener('input',()=>{sel=0;renderPal()});
 pr.addEventListener('click',e=>{const a=e.target.closest('a');if(a&&a.getAttribute('href')==='#'){e.preventDefault();go(+a.dataset.i)}});
 pal.addEventListener('click',e=>{if(e.target===pal)closePal()});
 document.addEventListener('keydown',e=>{const typing=/INPUT|TEXTAREA/.test(document.activeElement.tagName);
  if((e.key==='k'&&(e.metaKey||e.ctrlKey))||(e.key==='/'&&!typing)){e.preventDefault();pal.hidden?openPal():closePal();return}
  if(pal.hidden)return;if(e.key==='Escape')closePal();if(e.key==='ArrowDown'){sel=Math.min(sel+1,pal._items.length-1);renderPal();e.preventDefault()}if(e.key==='ArrowUp'){sel=Math.max(sel-1,0);renderPal();e.preventDefault()}if(e.key==='Enter'){e.preventDefault();go(sel)}})}
wire();})();
